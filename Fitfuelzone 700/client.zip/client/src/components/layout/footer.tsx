import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div className="fade-in-delay-1">
            <div className="text-2xl font-bold mb-4">
              <i className="fas fa-fire mr-2 pulse-glow"></i>
              <span className="gradient-shift bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">FitFuelZone</span>
            </div>
            <p className="text-gray-400 mb-4">Fuel Your Body. Fire Up Your Mind. 💪</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 scale-on-hover" data-testid="link-facebook">
                <i className="fab fa-facebook rotate-on-hover"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 scale-on-hover" data-testid="link-instagram">
                <i className="fab fa-instagram rotate-on-hover"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 scale-on-hover" data-testid="link-twitter">
                <i className="fab fa-twitter rotate-on-hover"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-all duration-300 scale-on-hover" data-testid="link-youtube">
                <i className="fab fa-youtube rotate-on-hover"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-home">Home</Link></li>
              <li><Link href="/workouts" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-workouts">Workouts</Link></li>
              <li><Link href="/nutrition" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-nutrition">Nutrition</Link></li>
              <li><Link href="/motivation" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-motivation">Motivation</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-about">About Us</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-contact">Contact</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-faq">FAQ</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-footer-privacy">Privacy Policy</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold mb-4">Stay Updated</h3>
            <p className="text-gray-400 text-sm mb-4">Get the latest fitness tips and motivation</p>
            <div className="flex">
              <Input 
                type="email" 
                placeholder="Your email" 
                className="bg-gray-800 text-white border-gray-700 rounded-r-none focus:border-primary"
                data-testid="input-newsletter-email"
              />
              <Button 
                variant="default" 
                className="bg-primary hover:bg-blue-700 rounded-l-none"
                data-testid="button-newsletter-subscribe"
              >
                <i className="fas fa-paper-plane"></i>
              </Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400 text-sm fade-in-delay-3">
          <p>&copy; 2024 FitFuelZone. All rights reserved. Created with passion for your fitness journey. ❤️</p>
        </div>
      </div>
    </footer>
  );
}
