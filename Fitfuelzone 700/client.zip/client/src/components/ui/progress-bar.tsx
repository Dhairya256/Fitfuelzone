import { cn } from "@/lib/utils";

interface ProgressBarProps {
  value: number;
  max?: number;
  className?: string;
  color?: "primary" | "secondary" | "accent" | "purple" | "orange" | "green" | "pink" | "indigo";
  label?: string;
  description?: string;
}

export function ProgressBar({ 
  value, 
  max = 100, 
  className, 
  color = "primary",
  label,
  description 
}: ProgressBarProps) {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100);
  
  const colorClasses = {
    primary: "bg-primary",
    secondary: "bg-secondary", 
    accent: "bg-accent",
    purple: "bg-purple-500",
    orange: "bg-orange-500",
    green: "bg-green-500",
    pink: "bg-pink-500",
    indigo: "bg-indigo-500"
  };

  return (
    <div className={cn("space-y-2", className)}>
      {(label || description) && (
        <div className="flex justify-between items-center">
          {label && <span className="text-sm font-medium text-gray-700">{label}</span>}
          {description && <span className="text-sm text-gray-500">{description}</span>}
        </div>
      )}
      <div className="w-full bg-gray-200 rounded-full h-3">
        <div 
          className={cn("h-3 rounded-full progress-bar", colorClasses[color])}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
}
