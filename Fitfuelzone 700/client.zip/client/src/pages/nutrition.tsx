import { Card, CardContent } from "@/components/ui/card";

const meals = [
  {
    title: "Power Breakfast Bowl",
    image: "https://images.unsplash.com/photo-1525385133512-2f3bdd039054?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Start your day with this nutrient-packed bowl that provides sustained energy for your workouts.",
    calories: 420,
    protein: "18g",
    fiber: "12g",
    ingredients: [
      "Rolled oats with almond milk",
      "Fresh berries and banana slices", 
      "Greek yogurt and chia seeds",
      "Honey and crushed almonds"
    ],
    benefits: "Sustained energy, muscle recovery"
  },
  {
    title: "Rainbow Quinoa Bowl",
    image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "A complete protein source packed with colorful vegetables to fuel your afternoon activities.",
    calories: 380,
    protein: "16g",
    fiber: "8g",
    ingredients: [
      "Fluffy quinoa base",
      "Roasted bell peppers and zucchini",
      "Cherry tomatoes and cucumber", 
      "Tahini dressing with lemon"
    ],
    benefits: "Complete amino acids, antioxidants"
  },
  {
    title: "Green Energy Smoothie",
    image: "https://images.unsplash.com/photo-1610970881699-44a5587cabec?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Perfect pre or post-workout smoothie packed with nutrients to boost energy and aid recovery.",
    calories: 220,
    protein: "12g",
    fiber: "6g",
    ingredients: [
      "Fresh spinach and kale",
      "Pineapple and mango chunks",
      "Protein powder (plant-based)",
      "Coconut water and lime juice"
    ],
    benefits: "Quick energy, vitamin boost"
  },
  {
    title: "Mediterranean Power Salad",
    image: "https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "A satisfying dinner salad with plant-based protein and healthy fats for muscle recovery.",
    calories: 350,
    protein: "14g",
    fiber: "10g",
    ingredients: [
      "Chickpeas and mixed greens",
      "Cherry tomatoes and olives",
      "Feta cheese and red onion",
      "Olive oil and herb dressing"
    ],
    benefits: "Heart-healthy fats, muscle repair"
  },
  {
    title: "Protein-Rich Lentil Curry",
    image: "https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Warming and nourishing curry loaded with plant-based protein and anti-inflammatory spices.",
    calories: 290,
    protein: "20g",
    fiber: "15g",
    ingredients: [
      "Red lentils and mixed vegetables",
      "Turmeric and ginger spices",
      "Coconut milk base",
      "Served with brown rice"
    ],
    benefits: "Anti-inflammatory, protein-rich"
  },
  {
    title: "Energy Power Balls",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Naturally sweet treat perfect for post-workout recovery or healthy dessert option.",
    calories: 150,
    protein: "6g",
    fiber: "4g",
    ingredients: [
      "Medjool dates and cashews",
      "Rolled oats and chia seeds",
      "Dark chocolate chips",
      "Coconut flakes coating"
    ],
    benefits: "Natural sugars, healthy fats"
  }
];

export default function Nutrition() {
  return (
    <div className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 slide-in-up" data-testid="text-nutrition-title">
            <i className="fas fa-leaf text-green-500 mr-3 float-animation"></i>
            Healthy Nutrition Plans
            <i className="fas fa-seedling text-green-600 ml-3 rotate-on-hover"></i>
          </h1>
          <p className="text-xl text-gray-600 fade-in-delay-1" data-testid="text-nutrition-subtitle">
            Energizing vegetarian meals for optimal fitness results 🌱
          </p>
          <div className="bg-secondary/10 rounded-2xl p-6 mt-8 max-w-4xl mx-auto fade-in-delay-2 scale-on-hover">
            <blockquote className="text-lg italic text-gray-700 font-medium" data-testid="text-nutrition-quote">
              "Let food be thy medicine and medicine be thy food. Every meal is an opportunity to nourish your body and fuel your dreams." ✨
            </blockquote>
            <cite className="block text-sm text-secondary font-semibold mt-2">- Ancient Wisdom</cite>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {meals.map((meal, index) => (
            <Card 
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-shadow duration-300"
              data-testid={`card-meal-${index}`}
            >
              <img 
                src={meal.image} 
                alt={meal.title}
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{meal.title}</h3>
                <p className="text-gray-600 mb-4">{meal.description}</p>
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center">
                    <div className="text-primary font-bold text-lg" data-testid={`text-calories-${index}`}>
                      {meal.calories}
                    </div>
                    <div className="text-xs text-gray-500">Calories</div>
                  </div>
                  <div className="text-center">
                    <div className="text-secondary font-bold text-lg" data-testid={`text-protein-${index}`}>
                      {meal.protein}
                    </div>
                    <div className="text-xs text-gray-500">Protein</div>
                  </div>
                  <div className="text-center">
                    <div className="text-accent font-bold text-lg" data-testid={`text-fiber-${index}`}>
                      {meal.fiber}
                    </div>
                    <div className="text-xs text-gray-500">Fiber</div>
                  </div>
                </div>
                <ul className="text-sm text-gray-600 space-y-1 mb-4">
                  {meal.ingredients.map((ingredient, ingredientIndex) => (
                    <li key={ingredientIndex}>• {ingredient}</li>
                  ))}
                </ul>
                <div className="text-xs text-secondary font-semibold">
                  <i className="fas fa-leaf mr-1"></i>Benefits: {meal.benefits}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
