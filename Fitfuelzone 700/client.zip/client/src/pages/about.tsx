import { Card, CardContent } from "@/components/ui/card";

const values = [
  {
    icon: "fas fa-heart",
    title: "Beginner-Friendly",
    description: "Every program is designed with beginners in mind, ensuring you never feel overwhelmed or left behind.",
    color: "bg-primary/10 text-primary"
  },
  {
    icon: "fas fa-leaf", 
    title: "Sustainable Health",
    description: "We focus on building lasting habits rather than quick fixes, promoting long-term wellness and vitality.",
    color: "bg-secondary/10 text-secondary"
  },
  {
    icon: "fas fa-users",
    title: "Inclusive Community", 
    description: "A judgment-free zone where everyone is welcome, supported, and celebrated for their unique journey.",
    color: "bg-accent/10 text-accent"
  }
];

export default function About() {
  return (
    <div className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 bounce-in" data-testid="text-about-title">
            <i className="fas fa-users text-blue-500 mr-3 float-animation"></i>
            About FitFuelZone
            <i className="fas fa-medal text-yellow-500 ml-3 pulse-glow"></i>
          </h1>
          <p className="text-xl text-gray-600 fade-in-delay-1" data-testid="text-about-subtitle">
            Empowering beginners to transform their lives through fitness
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Mission statement side */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6" data-testid="text-mission-title">Our Mission</h2>
            <p className="text-gray-600 text-lg leading-relaxed mb-6" data-testid="text-mission-part1">
              FitFuelZone was born from a simple belief: fitness should be accessible, enjoyable, and sustainable for everyone, 
              especially those just starting their journey. We understand that beginning a fitness routine can feel overwhelming, 
              which is why we've created a supportive platform that meets you exactly where you are.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed mb-6" data-testid="text-mission-part2">
              Our comprehensive approach combines beginner-friendly workouts, nutritious vegetarian meal plans, and daily 
              motivation to help you build lasting healthy habits. We believe that small, consistent steps lead to remarkable 
              transformations, and we're here to guide you through every rep, every meal, and every milestone.
            </p>
            <p className="text-gray-600 text-lg leading-relaxed" data-testid="text-mission-part3">
              Whether you're looking to build strength, improve your energy, or simply feel more confident in your own skin, 
              FitFuelZone provides the tools, knowledge, and encouragement you need to succeed. Your fitness journey starts here, 
              and we're honored to be part of it.
            </p>
          </div>
          
          {/* Mission imagery */}
          <div className="lg:text-right">
            <img 
              src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Community fitness and wellness" 
              className="rounded-2xl shadow-2xl w-full"
            />
          </div>
        </div>

        {/* Founder Section */}
        <Card className="bg-white rounded-2xl shadow-xl mb-16" data-testid="card-founder">
          <CardContent className="p-8 lg:p-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Meet Our Founder</h2>
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              {/* Founder photo */}
              <div className="text-center">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400" 
                  alt="Dhairya Sindhu - Founder of FitFuelZone" 
                  className="w-64 h-64 object-cover rounded-full mx-auto shadow-2xl mb-6"
                />
                <h3 className="text-2xl font-bold text-gray-900" data-testid="text-founder-name">Dhairya Sindhu</h3>
                <p className="text-secondary font-semibold">Founder & Fitness Enthusiast</p>
              </div>
              
              <div>
                <p className="text-gray-600 text-lg leading-relaxed mb-6" data-testid="text-founder-story-part1">
                  "My own fitness journey began with confusion, intimidation, and countless failed attempts. I remember standing 
                  in my living room, struggling to complete even the simplest exercises, feeling like I was the only person who 
                  couldn't figure it out."
                </p>
                <p className="text-gray-600 text-lg leading-relaxed mb-6" data-testid="text-founder-story-part2">
                  "After years of trial and error, I discovered that the key wasn't finding the perfect workout or the strictest 
                  diet—it was finding an approach that felt sustainable and enjoyable. This realization inspired me to create 
                  FitFuelZone: a place where beginners can start their journey without judgment, with clear guidance, and with 
                  the encouragement they deserve."
                </p>
                <p className="text-gray-600 text-lg leading-relaxed mb-6" data-testid="text-founder-story-part3">
                  "Today, I'm passionate about helping others avoid the struggles I faced and instead discover the joy that 
                  comes from taking care of your body. Every workout plan, every meal suggestion, and every motivational quote 
                  on this platform comes from my genuine desire to see you succeed."
                </p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary" data-testid="text-experience">5+</div>
                    <div className="text-sm text-gray-500">Years Experience</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-secondary" data-testid="text-people-helped">500+</div>
                    <div className="text-sm text-gray-500">People Helped</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent" data-testid="text-passion">∞</div>
                    <div className="text-sm text-gray-500">Passion</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Values Section */}
        <div className="grid md:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <div 
              key={index}
              className={`text-center p-6 ${value.color.split(' ')[0]} rounded-2xl`}
              data-testid={`card-value-${index}`}
            >
              <i className={`${value.icon} ${value.color.split(' ')[1]} text-4xl mb-4`}></i>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
              <p className="text-gray-600">{value.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
