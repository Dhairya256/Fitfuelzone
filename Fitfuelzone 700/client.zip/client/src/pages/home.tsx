import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="fade-in">
      {/* Hero Section */}
      <div className="relative min-h-screen flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080" 
            alt="Modern fitness lifestyle" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/70 to-secondary/70"></div>
        </div>
        
        <div className="relative z-10 text-center text-white px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 slide-in-up" data-testid="text-hero-title">
            Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-orange-300 gradient-shift">FitFuelZone</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 font-medium fade-in-delay-1" data-testid="text-hero-subtitle">
            Fuel Your Body. Fire Up Your Mind. 💪
          </p>
          <div className="fade-in-delay-2">
            <Link href="/workouts">
              <Button 
                size="lg"
                className="bg-white text-primary px-8 py-4 rounded-full text-lg font-semibold hover:bg-gray-100 scale-on-hover pulse-glow shadow-2xl"
                data-testid="button-start-journey"
              >
                Start Your Journey <i className="fas fa-rocket ml-2 float-animation"></i>
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Feature Preview Cards */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12" data-testid="text-features-title">
            Transform Your Life Today
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Workout Preview */}
            <div className="bg-gradient-to-br from-primary to-blue-600 text-white p-8 rounded-2xl shadow-xl scale-on-hover gradient-shift fade-in-delay-1" data-testid="card-workouts-preview">
              <i className="fas fa-dumbbell text-4xl mb-4 rotate-on-hover"></i>
              <h3 className="text-xl font-bold mb-4">Weekly Workouts</h3>
              <p className="mb-6">Beginner-friendly home workout plans designed to build strength and endurance.</p>
              <Link href="/workouts">
                <Button 
                  variant="secondary"
                  className="bg-white text-primary hover:bg-gray-100 scale-on-hover"
                  data-testid="button-explore-workouts"
                >
                  Explore Workouts <i className="fas fa-arrow-right ml-2"></i>
                </Button>
              </Link>
            </div>
            
            {/* Nutrition Preview */}
            <div className="bg-gradient-to-br from-secondary to-green-600 text-white p-8 rounded-2xl shadow-xl scale-on-hover gradient-shift fade-in-delay-2" data-testid="card-nutrition-preview">
              <i className="fas fa-apple-alt text-4xl mb-4 float-animation"></i>
              <h3 className="text-xl font-bold mb-4">Healthy Nutrition</h3>
              <p className="mb-6">Energizing vegetarian meal plans with complete nutritional information.</p>
              <Link href="/nutrition">
                <Button 
                  variant="secondary"
                  className="bg-white text-secondary hover:bg-gray-100 scale-on-hover"
                  data-testid="button-view-meals"
                >
                  View Meals <i className="fas fa-leaf ml-2"></i>
                </Button>
              </Link>
            </div>
            
            {/* Motivation Preview */}
            <div className="bg-gradient-to-br from-accent to-cyan-600 text-white p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-transform duration-300" data-testid="card-motivation-preview">
              <i className="fas fa-heart text-4xl mb-4"></i>
              <h3 className="text-xl font-bold mb-4">Daily Motivation</h3>
              <p className="mb-6">Inspiring quotes and success stories to keep you motivated on your journey.</p>
              <Link href="/motivation">
                <Button 
                  variant="secondary"
                  className="bg-white text-accent hover:bg-gray-100"
                  data-testid="button-get-inspired"
                >
                  Get Inspired
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
