import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ContactForm {
  name: string;
  email: string;
  subject: string;
  message: string;
}

export default function Contact() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<ContactForm>({
    name: "",
    email: "",
    subject: "",
    message: ""
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactForm) => {
      const response = await apiRequest("POST", "/api/contact", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out! We'll get back to you within 24 hours.",
      });
      setFormData({ name: "", email: "", subject: "", message: "" });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof ContactForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 slide-in-up" data-testid="text-contact-title">
            <i className="fas fa-paper-plane text-blue-500 mr-3 float-animation"></i>
            Get In Touch
            <i className="fas fa-heart text-red-500 ml-3 pulse-glow"></i>
          </h1>
          <p className="text-xl text-gray-600 fade-in-delay-1" data-testid="text-contact-subtitle">
            We'd love to hear from you and support your fitness journey
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card className="bg-white rounded-2xl shadow-xl scale-on-hover fade-in-delay-2" data-testid="card-contact-form">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                <i className="fas fa-envelope text-primary mr-2 rotate-on-hover"></i>
                Send Us a Message
              </h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="name">Your Name *</Label>
                  <Input
                    id="name"
                    type="text"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    className="mt-2"
                    required
                    data-testid="input-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    className="mt-2"
                    required
                    data-testid="input-email"
                  />
                </div>
                
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Select value={formData.subject} onValueChange={(value) => handleInputChange("subject", value)}>
                    <SelectTrigger className="mt-2" data-testid="select-subject">
                      <SelectValue placeholder="Choose a topic" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General Inquiry</SelectItem>
                      <SelectItem value="workout">Workout Question</SelectItem>
                      <SelectItem value="nutrition">Nutrition Help</SelectItem>
                      <SelectItem value="technical">Technical Support</SelectItem>
                      <SelectItem value="feedback">Feedback</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="message">Your Message *</Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleInputChange("message", e.target.value)}
                    rows={5}
                    className="mt-2"
                    required
                    data-testid="textarea-message"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary hover:bg-blue-700"
                  disabled={contactMutation.isPending}
                  data-testid="button-submit"
                >
                  {contactMutation.isPending ? "Sending..." : "Send Message"} 
                  <i className="fas fa-paper-plane ml-2"></i>
                </Button>
              </form>
            </CardContent>
          </Card>
          
          {/* Contact Info */}
          <div>
            <Card className="bg-gradient-to-br from-primary to-blue-600 text-white mb-8" data-testid="card-contact-info">
              <CardContent className="p-8">
                <h2 className="text-2xl font-bold mb-6">Let's Connect</h2>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <i className="fas fa-envelope text-xl mr-4"></i>
                    <span data-testid="text-email">hello@fitfuelzone.com</span>
                  </div>
                  <div className="flex items-center">
                    <i className="fas fa-phone text-xl mr-4"></i>
                    <span data-testid="text-phone">+1 (555) 123-FITNESS</span>
                  </div>
                  <div className="flex items-center">
                    <i className="fas fa-clock text-xl mr-4"></i>
                    <span data-testid="text-hours">Mon-Fri: 9AM - 6PM EST</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white rounded-2xl shadow-xl mb-8" data-testid="card-social-links">
              <CardContent className="p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Follow Our Journey</h3>
                <div className="grid grid-cols-2 gap-4">
                  <a href="#" className="bg-blue-50 text-primary p-4 rounded-lg text-center hover:bg-blue-100 transition-colors" data-testid="link-facebook">
                    <i className="fab fa-facebook text-2xl mb-2"></i>
                    <div className="text-sm font-semibold">Facebook</div>
                  </a>
                  <a href="#" className="bg-blue-50 text-accent p-4 rounded-lg text-center hover:bg-blue-100 transition-colors" data-testid="link-instagram">
                    <i className="fab fa-instagram text-2xl mb-2"></i>
                    <div className="text-sm font-semibold">Instagram</div>
                  </a>
                  <a href="#" className="bg-green-50 text-secondary p-4 rounded-lg text-center hover:bg-green-100 transition-colors" data-testid="link-youtube">
                    <i className="fab fa-youtube text-2xl mb-2"></i>
                    <div className="text-sm font-semibold">YouTube</div>
                  </a>
                  <a href="#" className="bg-blue-50 text-primary p-4 rounded-lg text-center hover:bg-blue-100 transition-colors" data-testid="link-twitter">
                    <i className="fab fa-twitter text-2xl mb-2"></i>
                    <div className="text-sm font-semibold">Twitter</div>
                  </a>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-secondary/10 rounded-2xl" data-testid="card-response-promise">
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Response Promise</h3>
                <p className="text-gray-600 text-sm">
                  We typically respond to all inquiries within 24 hours. For urgent matters, 
                  please use our phone number during business hours.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
