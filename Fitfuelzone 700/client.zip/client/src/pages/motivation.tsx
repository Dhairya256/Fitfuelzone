import { Card, CardContent } from "@/components/ui/card";
import { ProgressBar } from "@/components/ui/progress-bar";
import { Button } from "@/components/ui/button";

const quotes = [
  {
    quote: "The only bad workout is the one that didn't happen.",
    author: "Fitness Wisdom",
    color: "from-primary to-blue-600"
  },
  {
    quote: "Success starts with self-discipline.",
    author: "Daily Motivation", 
    color: "from-secondary to-green-600"
  },
  {
    quote: "Your body can do it. It's time to convince your mind.",
    author: "Mindset Coaching",
    color: "from-accent to-cyan-600"
  },
  {
    quote: "Progress, not perfection.",
    author: "Self-Improvement",
    color: "from-purple-500 to-purple-700"
  },
  {
    quote: "Stronger than yesterday, better than before.",
    author: "Personal Growth",
    color: "from-orange-500 to-red-600"
  },
  {
    quote: "Every rep counts, every day matters.",
    author: "Consistency Matters",
    color: "from-pink-500 to-rose-600"
  }
];

const progressData = [
  { label: "Weekly Workouts", description: "4/5 completed", value: 80, color: "primary" as const },
  { label: "Daily Water Intake", description: "6/8 glasses", value: 75, color: "accent" as const },
  { label: "Healthy Meals", description: "20/21 this week", value: 95, color: "secondary" as const },
  { label: "Sleep Quality", description: "7.5/8 hours average", value: 94, color: "purple" as const },
  { label: "Push-up Progress", description: "15/20 goal", value: 75, color: "orange" as const },
  { label: "Weight Goal", description: "12/15 lbs lost", value: 80, color: "green" as const },
  { label: "Flexibility", description: "Excellent progress", value: 85, color: "pink" as const },
  { label: "Overall Fitness", description: "Amazing improvement", value: 88, color: "indigo" as const }
];

export default function Motivation() {
  return (
    <div className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 bounce-in" data-testid="text-motivation-title">
            <i className="fas fa-star text-yellow-500 mr-3 pulse-glow"></i>
            Daily Motivation
            <i className="fas fa-trophy text-yellow-600 ml-3 float-animation"></i>
          </h1>
          <p className="text-xl text-gray-600 fade-in-delay-1" data-testid="text-motivation-subtitle">
            Inspiration to fuel your fitness journey
          </p>
        </div>

        {/* Daily Quotes Section */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {quotes.map((item, index) => (
            <div 
              key={index}
              className={`bg-gradient-to-br ${item.color} text-white p-8 rounded-2xl shadow-xl scale-on-hover gradient-shift fade-in-delay-1`}
              data-testid={`card-quote-${index}`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <i className="fas fa-quote-left text-3xl mb-4 opacity-75 float-animation"></i>
              <blockquote className="text-lg mb-4">{item.quote}</blockquote>
              <cite className="text-sm opacity-90">- {item.author}</cite>
            </div>
          ))}
        </div>

        {/* Success Story Section */}
        <Card className="bg-white rounded-2xl shadow-xl mb-16" data-testid="card-success-story">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Success Story Spotlight</h2>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <img 
                src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Fitness transformation success story" 
                className="rounded-xl shadow-lg w-full h-auto"
              />
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4" data-testid="text-success-story-title">
                  Sarah's Amazing Journey
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed" data-testid="text-success-story-part1">
                  "Six months ago, I could barely do a single push-up. I was intimidated by gyms and felt lost about where to start. 
                  FitFuelZone changed everything for me. The beginner-friendly workouts gave me confidence, and the nutrition plans 
                  helped me fuel my body properly."
                </p>
                <p className="text-gray-600 mb-6 leading-relaxed" data-testid="text-success-story-part2">
                  "Now I can do 20 push-ups in a row, I've lost 25 pounds, and most importantly, I've gained incredible confidence. 
                  The daily motivation quotes kept me going on tough days. This isn't just about fitness - it's about 
                  becoming the best version of yourself."
                </p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary" data-testid="text-weight-lost">25 lbs</div>
                    <div className="text-sm text-gray-500">Weight Lost</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-secondary" data-testid="text-journey-time">6 months</div>
                    <div className="text-sm text-gray-500">Journey Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent" data-testid="text-confidence">100%</div>
                    <div className="text-sm text-gray-500">Confidence</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Goal Tracker Section */}
        <Card className="bg-white rounded-2xl shadow-xl" data-testid="card-goal-tracker">
          <CardContent className="p-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Goal Tracker</h2>
            <p className="text-gray-600 text-center mb-8">
              Track your progress with these visual indicators. Set your goals and watch your achievements grow!
            </p>
            
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-6">
                {progressData.slice(0, 4).map((item, index) => (
                  <ProgressBar
                    key={index}
                    value={item.value}
                    label={item.label}
                    description={item.description}
                    color={item.color}
                    data-testid={`progress-${index}`}
                  />
                ))}
              </div>
              
              <div className="space-y-6">
                {progressData.slice(4).map((item, index) => (
                  <ProgressBar
                    key={index + 4}
                    value={item.value}
                    label={item.label}
                    description={item.description}
                    color={item.color}
                    data-testid={`progress-${index + 4}`}
                  />
                ))}
              </div>
            </div>
            
            <div className="text-center mt-8">
              <Button 
                size="lg"
                className="bg-primary text-white hover:bg-blue-700"
                data-testid="button-update-progress"
              >
                Update My Progress
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
