import { Card, CardContent } from "@/components/ui/card";

const workouts = [
  {
    title: "Push-up Power",
    icon: "fas fa-fist-raised",
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Build upper body strength with these progressive push-up variations. Perfect for beginners to advanced practitioners.",
    duration: "15-20 min",
    level: "Beginner",
    color: "text-primary",
    exercises: [
      "Wall Push-ups (3 sets of 10)",
      "Knee Push-ups (3 sets of 8)", 
      "Standard Push-ups (2 sets of 5)"
    ]
  },
  {
    title: "Core Crusher",
    icon: "fas fa-circle",
    image: "https://images.unsplash.com/photo-1434608519344-49d77a699e1d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Strengthen your core with these effective exercises that target all abdominal muscles and improve stability.",
    duration: "12-15 min",
    level: "Beginner",
    color: "text-secondary",
    exercises: [
      "Planks (3 sets of 30 sec)",
      "Crunches (3 sets of 12)",
      "Bicycle Crunches (3 sets of 10)"
    ]
  },
  {
    title: "Flexibility Flow",
    icon: "fas fa-leaf",
    image: "https://images.unsplash.com/photo-1506629905496-f21bb4ab9199?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Improve flexibility and reduce muscle tension with these gentle stretching routines perfect for recovery days.",
    duration: "10-15 min",
    level: "Recovery",
    color: "text-accent",
    exercises: [
      "Cat-Cow Stretches (2 min)",
      "Hip Flexor Stretches (1 min each)",
      "Shoulder Rolls (30 sec)"
    ]
  },
  {
    title: "HIIT Blast",
    icon: "fas fa-bolt",
    image: "https://images.unsplash.com/photo-1434608519344-49d77a699e1d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "High-intensity interval training to boost metabolism and burn calories effectively in minimal time.",
    duration: "20-25 min",
    level: "Intermediate",
    color: "text-yellow-500",
    exercises: [
      "Jumping Jacks (30 sec on/15 sec rest)",
      "Burpees (20 sec on/20 sec rest)",
      "Mountain Climbers (30 sec on/15 sec rest)"
    ]
  },
  {
    title: "Lower Power",
    icon: "fas fa-running",
    image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Build strong legs and glutes with these foundational lower body exercises that require no equipment.",
    duration: "18-22 min",
    level: "Beginner",
    color: "text-primary",
    exercises: [
      "Bodyweight Squats (3 sets of 12)",
      "Lunges (3 sets of 8 each leg)",
      "Glute Bridges (3 sets of 10)"
    ]
  },
  {
    title: "Dance Cardio",
    icon: "fas fa-music",
    image: "https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=300",
    description: "Fun cardio workout combining dance moves with fitness. Burn calories while having a great time!",
    duration: "25-30 min",
    level: "Fun",
    color: "text-accent",
    exercises: [
      "Warm-up Dance (5 min)",
      "High-energy Routine (15 min)",
      "Cool-down Stretch (5 min)"
    ]
  }
];

export default function Workouts() {
  return (
    <div className="py-16 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4 slide-in-up" data-testid="text-workouts-title">
            <i className="fas fa-fire text-orange-500 mr-3 float-animation"></i>
            Weekly Home Workouts
            <i className="fas fa-heart text-red-500 ml-3 pulse-glow"></i>
          </h1>
          <p className="text-xl text-gray-600 fade-in-delay-1" data-testid="text-workouts-subtitle">
            Beginner-friendly routines to build strength and endurance
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {workouts.map((workout, index) => (
            <Card 
              key={index} 
              className="bg-white rounded-2xl shadow-lg overflow-hidden scale-on-hover fade-in-delay-1"
              data-testid={`card-workout-${index}`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={workout.image} 
                  alt={workout.title}
                  className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 text-sm font-medium">
                  {workout.level}
                </div>
              </div>
              <CardContent className="p-6">
                <div className="flex items-center mb-3">
                  <i className={`${workout.icon} ${workout.color} text-2xl mr-3 rotate-on-hover`}></i>
                  <h3 className="text-xl font-bold text-gray-900">{workout.title}</h3>
                </div>
                <p className="text-gray-600 mb-4">{workout.description}</p>
                <div className="flex justify-between items-center text-sm text-gray-500 mb-4">
                  <span><i className="fas fa-clock mr-1"></i>{workout.duration}</span>
                  <span><i className="fas fa-fire mr-1"></i>{workout.level}</span>
                </div>
                <ul className="text-sm text-gray-600 space-y-1">
                  {workout.exercises.map((exercise, exerciseIndex) => (
                    <li key={exerciseIndex}>• {exercise}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
